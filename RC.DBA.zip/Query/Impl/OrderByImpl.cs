﻿using RC.DBA.Metamodel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace RC.DBA.Query.Impl
{
    class OrderByImpl<T> : IOrderBy<T>
    {
        QueryContext _ctx;
        IAliasExpression _alias;
        List<IOrderByExpression> _expressions;

        public OrderByImpl(QueryContext ctx, IAliasExpression alias)
        {
            _ctx = ctx;
            _alias = alias;
        }

        public StringBuilder CompileToSQL(StringBuilder sql)
        {
            if (_expressions == null || _expressions.Count == 0) return sql;

            sql.AppendLine().Append("ORDER BY ");
            _expressions[0].CompileToSQL(sql);
            for (int i = 1; i < _expressions.Count; i++)
            {
                _expressions[i].CompileToSQL(sql.Append(','));
            }

            return sql;
        }

        public IOrderBy Add(IOrderByExpression expression)
        {
            Expressions().Add(expression);
            return this;
        }

        public IList<IOrderByExpression> Expressions()
        {
            return _expressions ?? (_expressions = new List<IOrderByExpression>());
        }

        public IOrderByExpression OrderBy<TProp>(Expression<Func<T, TProp>> expression)
        {
            var memberInfo = Helper.Member(expression);
            var entityAttr = _ctx.ModelManager.Entity<T>().GetAttribute(memberInfo.Name);
            return new OrderByExpressionImpl(_alias, entityAttr);

        }

        public IOrderByExpression OrderBy<TProp>(Expression<Func<T, TProp>> expression, bool desc)
        {
            return OrderBy(expression).Desc();
        }

        public IOrderBy OrderBy(params IOrderBy[] orderBy)
        {
            for (int i = 0; i < orderBy.Length; i++)
            {
                _expressions.AddRange(orderBy[i].Expressions());
            }

            return this;
        }

        public IOrderBy OrderBy(IEnumerable<IOrderBy> orderBy)
        {
            foreach (var x in orderBy)
            {
                _expressions.AddRange(x.Expressions());
            }

            return this;
        }
    }

    class OrderByExpressionImpl : IOrderByExpression
    {
        private IAliasExpression _alias;
        IEntityAttribute _entityAttribute;
        private bool _isDesc;
        public string Name => _entityAttribute.Name;

        public bool IsDesc { get => _isDesc; set => _isDesc = value; }

        public OrderByExpressionImpl(IAliasExpression alias, IEntityAttribute entityAttribute)
        {
            _alias = alias;
            _entityAttribute = entityAttribute;
        }
        public IOrderByExpression Asc()
        {
            _isDesc = false;
            return this;
        }

        public IOrderByExpression Desc()
        {
            _isDesc = true;
            return this; 
        }

        public StringBuilder CompileToSQL(StringBuilder sql)
        {
            _alias.CompileToSQL(sql)
                .Append('t').Append(_entityAttribute.EntityType.Table.Index)
                .Append('.').Append(_entityAttribute.Name);
            if (_isDesc)
                sql.Append(" DESC");

            return sql;
        }
        
    }
}
